package Com.JavaClass;

import java.io.FileNotFoundException;

public class ExceptionThrows {
	int a = 20 ;
	ExceptionThrows() throws FileNotFoundException
	{
	
	}
}
