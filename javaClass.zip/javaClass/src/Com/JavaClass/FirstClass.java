package Com.JavaClass;

public class FirstClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		public class Students implements Comparable<Students>{
//		    private int num;
//
//		    public int getNum() {
//		        return num;
//		    }
//		    public void setNum(int num) {
//		        this.num = num;
//		    }
//		    @Override
//		    public String toString() {
//		        return "Rank { num"+ num + "}";
//		    }
//		    public Students(int num) {
//		        this.num = num;
//		    }
//
////		    public int CompareTo(Students o) {
////		        return this.num - o.num;
////		    }
//
//		    @Override
//		    public int compareTo(Students o) {
//		        return this.num - o.num;
//		       // return 0;
//		    }
	
	
	
	
		}
		

	}


