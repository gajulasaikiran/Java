package Com.JavaClass;
import java.util.Collections;
import java.util.LinkedList;

public class ScondClass {

	public static void main(String[] args) {

		try {
			int a =20;
			int b = 30;
			int d = a/0;
				System.out.println(d);
		}
		catch(Exception ex) {
			System.out.println("exception occurs");
		}
		finally{
		System.out.println("CloseFile");
		}
	}

}
