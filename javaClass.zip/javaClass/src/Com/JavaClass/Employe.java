package Com.JavaClass;

public class Employe implements Comparable<Employe>{
	private int empId;
	private String empName;
	private long empSalary;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public long getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(long empSalary) {
		this.empSalary = empSalary;
	}
	public Employe(int empId, String empName, long empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	}
	@Override
	public String toString() {
		return "Employe [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + "]";
	}
	public int compareTo(Employe o) {
		// TODO Auto-generated method stub
		return this.empId-o.empId;
		//return empName.compareTo(empName);
	}
	
		
	
}