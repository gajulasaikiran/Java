package Com.JavaClass;

//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.Comparator;
//
public class TestClass{
//	
	public static void main(String args[]) {
//		
//	ArrayList<Employe> al = new ArrayList<>();
//	
//	al.add(new Employe(220,"mani",25000));
//	al.add(new Employe(210,"sumith",35000));
//	al.add(new Employe(205,"ankith",30000));
//	al.add(new Employe(203,"anil",50000));
//	
//	Collections.sort(al,Comparator.comparing(Employe::getEmpId));
//	System.out.println(al);
	//}
//		String originalStr = "Hello";
//		String reversedStr = "";

//		for (int i = 0; i < originalStr.length(); i++) {
//		  reversedStr = originalStr.charAt(i) + reversedStr;
//		}
//
//		System.out.println("Reversed string: "+ reversedStr);}
//	
	
//	for (int i=originalStr.length()-1 ; i>=0 ; i--) {
//		reversedStr =reversedStr+originalStr.charAt(i);
//		//System.out.println(reversedStr);
//	}System.out.println(reversedStr);
//		 int count = 1;  
//		    while (count <= 15) {  
//		    System.out.println(count % 2 == 1 ? "***" : "+++++");  
//		    ++count;  }
//	
	
	}
}