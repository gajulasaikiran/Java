package Com.JavaClass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CompairMethod {

	public static void main(String args[]) {

		ArrayList<Emp> al = new ArrayList<>();

		al.add(new Emp(200,"mani", 23000));
		al.add(new Emp(220, "mani", 25000));
		al.add(new Emp(210, "sumith", 35000));
		al.add(new Emp(205, "ankith", 30000));
		al.add(new Emp(203, "anil", 50000));
		

		Collections.sort(al, Comparator.comparing(Emp::getEmpId).thenComparing(Emp::getEmpSalary));
//	Collections.sort(al,Comparator.comparing(Emp::getEmpName));
		System.out.println(al);
	}
}
