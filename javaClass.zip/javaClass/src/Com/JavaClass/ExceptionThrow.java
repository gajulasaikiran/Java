package Com.JavaClass;
import java.io.IOException;
import java.util.Scanner;

// class YAException extends RuntimeException{
//	YAException(String msg)
//	{
//		super(msg);
//	}	
//}
// class ExceptionThrow{
//
//	 	public static void main(String args[]) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("enter ur age");
//	//void class age (int age) YAException {	
//		int age = sc.nextInt();
//		if (age<18) {
//			throw new YAException("not fit for vote");
//		}
//		else {
//			System.out.println("ur fit for vote ");
//		}
//	}
////		finally {
////			System.out.println("ur done");
////		}
//	 }
// }
import java.io.IOException;
public class ExceptionThrow
{
	
	public static void main(String args[]) throws IOException
	{
		int age = 17;
		CheckAge(age);
		System.out.println("votingProcess");
	}
	public static void CheckAge(int age)throws IOException
	{
		try 
		{
		if (age > 18)
		{
			System.out.println("you are elgible for vote");
		}
		else
		{
			throw new IOException ("ur not fit for voting");
		}
		}
		finally
		{
			System.out.println("traminated");
		}
	}
	
}











