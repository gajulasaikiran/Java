package Com.JavaClass;
//package javaClass;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class collection_methodRefference {

	public static void main(String[] args) {
		
		List<String> st = new ArrayList<>();
		ArrayList<Employe> emp = new ArrayList<>();

		emp.add(new Employe(220, "mani", 25000));
		emp.add(new Employe(210, "sumith", 35000));
		emp.add(new Employe(205, "ankith", 30000));
		emp.add(new Employe(203, "anil", 50000));
		
		System.out.println(emp);
		
		//Collections.sort(emp);
		
		//System.out.println(emp+"sorted");
		
        //emp.sort(Comparator.comparing(emp::getEmpId).than comparing(emp::getEmpName));
	}

	
}
