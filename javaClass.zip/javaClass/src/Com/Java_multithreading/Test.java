package Com.Java_multithreading;

//public class Test extends Thread{
//	
//	public void run()
//	{
//		System.out.println("multiThreading");
//	}
//	public class test2 extends Thread
//	{
//		public void run2() 
//		{
//		System.out.println("new Thread");	
//		}
//
//	
//		public static void main(String[] args) 
//		{	//main thread which is created by jvm
//		
//		Test t = new Test();  //thread 2
//		t.start();
//		test2 t2 = new test2();	//thread 3
//		t2.start();
//		
//		}
//	}
class MyThread1 extends Thread {

	public void run() {
		System.out.println("multiThreading");
	}
}

class MyThread2 extends Thread {
	public void run() {
		System.out.println("playing");
	}
}

class MyThread3 extends Thread {
	public void run() {
		System.out.println("running");
	}
}

class MyThread4 extends Thread {
	public void run() {
		System.out.println("sleeping");
	}
}

public class Test {
	public static void main(String[] args) { // main thread which is created by jvm

		MyThread1 t = new MyThread1(); // thread 2
		t.start();
		MyThread2 t2 = new MyThread2(); // thread 3
		t2.start();
		MyThread3 t3 = new MyThread3(); // thread 3
		t3.start();
		MyThread4 t4 = new MyThread4(); // thread 3
		t4.start();
	}
}
