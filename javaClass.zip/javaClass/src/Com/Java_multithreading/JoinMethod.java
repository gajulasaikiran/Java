package Com.Java_multithreading;

public class JoinMethod extends Thread {
	public void run() {
		try {
			for (int i = 1; i < 5; i++) {
				System.out.println(Thread.currentThread().getName() + i);
				Thread.sleep(500);
			}
		} catch (Exception e) {
			System.out.println("InterruptedException occurs");
		}
	}

	public static void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
		JoinMethod j = new JoinMethod();
		j.start();
		j.join();
		try {
			for (int i = 1; i < 5; i++) {
				System.out.println(Thread.currentThread().getName()+ i);
				Thread.sleep(500);
				//j.join();
			}
		} catch (Exception e) {
			System.out.println("InterruptedException occurs");
		} 
		System.out.println("main");

	}

}
