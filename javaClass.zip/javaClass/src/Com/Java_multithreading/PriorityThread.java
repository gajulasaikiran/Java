package Com.Java_multithreading;

public class PriorityThread extends Thread 
{
	public void run() {
		System.out.println("child thread");
		System.out.println(Thread.currentThread().getPriority());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("main thread");
		System.out.println(Thread.currentThread().getPriority());
		PriorityThread pt = new PriorityThread();
		pt.setPriority(MAX_PRIORITY);
		pt.start();
	}

}
