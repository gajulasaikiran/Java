package Com.Java_multithreading;

//class Test2 extends Thread
//{
//	public void run()
//	{
//		Thread.currentThread().setName("thiru");
//		System.out.println("theradName : testing class name");
//		System.out.println(Thread.currentThread().getName());
//	}
// 
//	public static void main(String args[]) {
//		
//		Test2 t = new Test2();
//		t.start();
//		System.out.println(Thread.currentThread().getName());
//
//	}	
//}
class Test2 extends Thread {
	public void run() {
		System.out.println("task is extended by :" + Thread.currentThread().getName());
		System.out.println(Thread.currentThread().isAlive());
	}

	public static void main(String args[]) {
		System.out.println("thirumal is printed by :" + Thread.currentThread().getName());
		Test2 t = new Test2();
		t.setName("thiru");
		t.start();
		Test2 t1 = new Test2();
		t1.setName("kumar");
		t1.start();
		System.out.println("hello");
		System.out.println(Thread.currentThread().isAlive());
		System.out.println(t.isAlive());

	}
}