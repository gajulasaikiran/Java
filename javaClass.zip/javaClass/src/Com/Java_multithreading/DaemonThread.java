package Com.Java_multithreading;

public class DaemonThread extends Thread {
	public void run() {
		System.out.println("hello");
	}

	public static void main(String[] args) {
	
		System.out.println("world");
		
		DaemonThread dt = new DaemonThread();
		dt.setDaemon(true);
		dt.start();
	}

}
