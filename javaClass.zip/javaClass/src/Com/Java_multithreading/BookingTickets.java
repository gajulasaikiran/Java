package Com.Java_multithreading;

public class BookingTickets {
	int totalSeats = 10;		//inserting the no.of Tickets available to Book 
	synchronized void bookSeats(int seats)	//insert the no.of Tickets wants to Book 
	{
		if (totalSeats >= seats) {
			System.out.println("seatsBooked Successfully");
			totalSeats = totalSeats - seats;				//After booking tickets changing the tickets total count
			System.out.println("Seats Left =" + totalSeats);
		} else {
			System.out.println("seats cannot be booked...!");
			System.out.println("Seats Left =" + totalSeats);
		}
	}
}
class bookingApp extends Thread {		//MAIN CLASS
	static BookingTickets b;			//	create reference  .......static is imp 
	int seats;

	public void run() {					//run method override		
		b.bookSeats(seats);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		b = new BookingTickets(); 		//   creating reference
		bookingApp thiru = new bookingApp();
		thiru.seats = 6;
		thiru.start();
 
		bookingApp anil = new bookingApp();
		anil.seats = 9;
		anil.start();

	}

}
