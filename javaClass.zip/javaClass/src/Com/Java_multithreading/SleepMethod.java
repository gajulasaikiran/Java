package Com.Java_multithreading;

public class SleepMethod extends Thread {

	public void run() {
	
		for (int i=1 ; i<=5 ; i++) {
			
		try {
			Thread.sleep(1000);
//        System.out.println(i);	
		}
		catch (Exception e )
		{
			System.out.println(e);
		}
		System.out.println(i);
		}
	}

	public static void main(String[] args) {

		// System.out.println("hello");
		SleepMethod sm = new SleepMethod();

		sm.start();

	}

}
