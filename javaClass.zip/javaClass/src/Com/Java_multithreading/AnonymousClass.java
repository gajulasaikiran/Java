package Com.Java_multithreading;

public class AnonymousClass {
	public static void main(String args[]) {
		Thread t =new Thread() {
			public void run() {
				System.out.print("hello");
			}
		};
		t.start();
		Thread t2 = new Thread() {
			public void run() {
				System.out.println("  world");
			}
		};
		t2.start();
	}

}
