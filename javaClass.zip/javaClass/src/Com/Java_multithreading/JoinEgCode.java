package Com.Java_multithreading;

class medical extends Thread {
	public void run() {
		try {
			System.out.println("medical Started");
			Thread.sleep(2000);
			System.out.println("medical complited");
		} catch (Exception e) {
			System.out.println("exception occurs");
		}
	}
}

class DrivingTest extends Thread {
	public void run() {
		try {
			System.out.println("Driving Test Started");
			Thread.sleep(1500);
			System.out.println("DrivingTest Complited");
		} catch (Exception e) {
			System.out.println("Exception occurs");
		}
	}
}

class Officer extends Thread {
	public void run() {
		try {
			System.out.println("office checking doc");
			Thread.sleep(1000);
			System.out.println("Officer sign Complited");
		} catch (Exception e) {
			System.out.println("Exception Occures");
		}
	}
}

public class JoinEgCode
{
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		medical m = new medical();
		m.start();
		m.join();

		DrivingTest dt = new DrivingTest();
		dt.start();
		dt.join();

		Officer o = new Officer();
		o.start();
	}
}
