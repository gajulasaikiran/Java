//package leetCode;
//
//public class frstClass {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}
//
//}
package Com.leetCode;

public class FirstClass {}

//	//public int titlNo(String s) {
//	public static void main(String args[]) {
//		String s = "Ac";
//		int ans = 0 ;
//		int p = 0 ; 
//		for (int i=s.length()-1 ; i>=0 ; i--) {
//			char c = s.charAt(i);
//			int val = (int)c - 65 + 1;
//			ans+= val*Math.pow(26, p);
//			p++;
//		}
//		//return ans;
//		System.out.println(ans);
//	}
//
//}
