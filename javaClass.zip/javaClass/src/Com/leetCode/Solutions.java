package Com.leetCode;

public class Solutions {

	public static void main(String[] args) {
//	int [] arr = new int [] {1,4,7,2,4,4,6,6,2,1,1};
//	int[] fr = new int[arr.length];
//	int visited = -1;
//	for (int i=0 ; i<arr.length ; i++) 
//	{
//		
//		int count = 1;
//		for(int j=i+1 ; j<arr.length ; j++) 
//		{
//			if (arr[i]==arr[j]) 
//			{
//				count++;
//				fr[j]=visited;
//				// System.out.println(count++);
//			}
//		}
//		if(fr[i]!=visited) {
//			fr[i]=count;
////			System.out.println(fr[i]  + arr[i]);
//		}
//	}
//for(int i=0 ; i<fr.length ; i++) {
//	if(fr[i]!=visited) {
//		System.out.println(fr[i]  + arr[i]);
//	}
//}-------------//---------------
		String s = "today is an holiday";
		int[] arr = new int[127];
		for (int i = 0; i < s.length(); i++) {

			arr[s.charAt(i)] = arr[s.charAt(i)] + 1;
		}
		int max = -1;
		char c = ' ';
		for (int i = 0; i < s.length(); i++) {
			if (max < arr[s.charAt(i)]) {
				max = arr[s.charAt(i)];
				c = s.charAt(i);
			}
		}

		System.out.println("max repeated char is  "  + c);

	}
}
