package Com.Strings;

public class ClassStrings {
	public static void main(String args[]){
		String s = new String("hello");
		s = s.concat(" World");
		System.out.println(s);
		
		StringBuffer sb = new StringBuffer();
		//sb = sb.append(" kumar");//
		System.out.println(sb);
		}
}

