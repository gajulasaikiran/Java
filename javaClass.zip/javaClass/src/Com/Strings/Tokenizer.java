package Com.Strings;

import java.util.StringTokenizer;

public class Tokenizer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringTokenizer st = new StringTokenizer("my name is khan", " ");   // /here we print word by word by using token method
		StringTokenizer st1 = new StringTokenizer("my name is thiru", " ");
		while (st.hasMoreTokens()) {
			System.out.println(st.nextToken());

		}

	}
}