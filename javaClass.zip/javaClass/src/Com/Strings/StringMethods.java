package Com.Strings;
import java.util.StringTokenizer;

public class StringMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String s1 = new String("hello");
//		String s2 = new String("hello");
//		String s3 = new String("World");
//		String s4 = "world" ;
//		String s5 = "world" ;
//		System.out.println(s1==s2);//address comparasion
//		System.out.println(s1.equals(s2));//obj comparasion
//		System.out.println(s4==s5);
//		System.out.println(s4.equals(s5));
		
		//System.out.println(s3.length());
		//System.out.println(s1.equals(s2));
		//byte[] s2 = {101,202,303};
//		char[] s2 = new char[]{"e","y","f"};
//		String a = new String("thiru");
//		System.out.println(s2);
//		System.out.println(a);
//		StringTokenizer st = new StringTokenizer("today is an holiday");// /here we print word by word by using token methodnt 
//		while(st.hasMoreTokens()) {
//			System.out.println(st.nextToken());
//		}
		//System.err.println("thiru");
		
//	String s1 = "tHiRu";
//	String s2 = "Thiru";
//	System.out.println(String.join("...",s1,s2));
//	System.out.println(s1+s2+10);
//	System.out.println(10+20+s1);
//	System.out.println(s1+10/5);
//	System.out.println(s1.concat(s2));
//	System.out.println(s1+10*20+s2);
//		String s1 = "today is an holiday";
//		System.out.println(s1.subSequence(3,9));    //extract fron 3rd letter to 9th lrtter
//		System.out.println(s1.substring(8,13));     //hera extract from 8th letter to 13th letter
		
//		String s1 = "today is an holiday";
//		System.out.println(s1.replace("an","the"));
//		System.out.println(s1.replaceAll("a","e"));
//		System.out.println(s1.replaceFirst("is","s"));
//		System.out.println(s1.replaceAll("an(.*)","the"));//it will replace the String then elimanate the upcoming words.
//		System.out.println(s1.replaceAll("an(. )","the"));
//	String s1 = "it's easy to learn java";
//	System.out.println(s1.indexOf("to"));
//	System.out.println(s1.lastIndexOf("a"));
//	System.out.println(s1.charAt(19));
//	System.out.println(s1.contains("java"));//
//	System.out.println(s1.startsWith("it")); //it will search is it staring with the same letter
//	System.out.println(s1.endsWith("a"));	
		
//		String s1 = "ThiRumL";
//		System.out.println(s1.toUpperCase());
//		System.out.println(s1.toLowerCase());
//		
//		int a = 10;
//		String s2 = String.valueOf(a);//==>to convert string to int we use "valueOf"
//		System.out.println(s2);
		
		
		 
		
		
		
//	20 a2 30
		
		
		
		
		
	} 
}
