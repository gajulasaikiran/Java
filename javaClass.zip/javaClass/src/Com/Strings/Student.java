package Com.Strings;

import java.io.Serializable;

public class Student implements Serializable {

	//public static void main(String[] args) {
		
		private int getId;
		private String getName;
		public int getGetId() {
			return getId;
		}
		public void setGetId(int getId) {
			this.getId = getId;
		}
		public String getGetName() {
			return getName;
		}
		public void setGetName(String getName) {
			this.getName = getName;
		}
		public Student(int getId, String getName) {
			super();
			this.getId = getId;
			this.getName = getName;
		}
		@Override
		public String toString() {
			return "Student [getId=" + getId + ", getName=" + getName + "]";
		}
		 
		
				
	}


