package Com.Strings;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class serializable {

	public static void main(String[] args) throws IOException {
		Student s = new Student(111,"thiru");
		FileOutputStream fout = new FileOutputStream("f.txt");
		ObjectOutputStream dec = new ObjectOutputStream(fout);
		dec.writeObject(s);
		dec.flush();
		
		//dec.close();
		System.out.println(dec);
		System.out.println(s);
		System.out.println(fout);
		System.out.println("success");
		
	}

}
