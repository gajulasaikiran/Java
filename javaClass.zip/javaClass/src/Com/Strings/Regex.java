package Com.Strings;

import java.util.regex.Pattern;

public class Regex {

	public static void main(String[] args) {
		
		//pattern matches has to meet the given pattern 
		
//		System.out.println(Pattern.matches("s", "sanam"));
//		System.out.println(Pattern.matches("s", "s"));	//true
//		System.out.println(Pattern.matches(".s", "as"));	//true
//		System.out.println(Pattern.matches(".s", "ais"));
//		System.out.println(Pattern.matches(".s", "haas"));
//		System.out.println(Pattern.matches("[aei]", "has"));
//		System.out.println(Pattern.matches("[aei]", "a"));	//true
//		System.out.println(Pattern.matches("[aei]", "aaeeii"));
//		System.out.println(Pattern.matches("\\d", "san"));
//		System.out.println(Pattern.matches("\\d", "6"));	//true
//		System.out.println(Pattern.matches("\\d", "56"));
//		System.out.println(Pattern.matches("\\D", "san"));
//		System.out.println(Pattern.matches("\\D", "s"));	//true
//		System.out.println(Pattern.matches("\\D", "6"));
//		System.out.println(Pattern.matches("\\D", "66"));
		
//		System.out.println(Pattern.matches("\\D*", "sanam"));//true
//		
//		System.out.println(Pattern.matches("[897]{1}[0-9]{9}","9984568678")); //true
//		System.out.println(Pattern.matches("[897]{1}[0-9]{9}","3984568678"));	//false
//		System.out.println(Pattern.matches("[897]{1}[0-9]{9}","998456867928"));	//false
		
		
		
		
	}

}
