package Com.Strings;

public class StringBuffer {

	public static void main(String[] args) {
		
	StringBuffer sb = new StringBuffer();
		//System.out.println(sb.length());	//review later
		
	
  	}
}
