package Com.prblm_Solving;

import java.io.CharArrayReader;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class AskedJavaPgrm  {
	
//	int a= 10;     				//instance varable 
//	static int b=20;			//static varable
	
	
	public static void  main(String args[]) {
//		AskedJavaPgrm obj = new AskedJavaPgrm();
//		
//		System.out.println(obj.a);
//		System.out.println(b);
		
		
//	int a=345;
//	
//	int rev = 0 ; 
//	
//	while(a!=0) {
//		rev = rev*10 + a%10;
//		a=a/10;	
//	}
//	System.out.println(rev);
		
		//-----------------//---------------//
		
//		int a = 3456;
		
//		StringBuffer sb = new StringBuffer(String.valueOf(a));
//		StringBuffer rev = sb.reverse();
//		System.out.println(rev);
		//-------------------------------//
		
////		String rev;
//		StringBuilder sb = new StringBuilder(a);
//		sb.append(a);
//		StringBuilder rev =sb.reverse();
//		System.out.println(rev);
		//---------------------------------------------//
		
//		
//		String str="thiru";
//		String rev = "";
//		
//		int length = str.length();        
//		
//		for(int i=length-1; i>=0; i--) {
//			rev = rev+str.charAt(i);
//		}
//		System.out.println(rev);
		
		//-----------------------------------------------//
		
//		using charactorArray
		
//		char a[]=str.toCharArray();
//		int len = a.length;
//		
//		for(int i=len-1; i>=0; i--) {
//			rev = rev+a[i];
//		}
//		System.out.println(rev);
		
		//--------------------------------------------------//
		
		//using StringBuffer
		
//		StringBuffer sb = new StringBuffer(str);
//		System.out.println(sb.reverse());
//		
		
		//---------------------------------------------------//
		
//		Palindrom Numver
//		int org_num=14541;
//		int num=org_num;
//		int rev = 0;
//		
//		while(num!=0) {
//			rev = rev*10 + num%10;
//			num = num/10;
//		}
//		System.out.println(rev);
//		if(rev == org_num) {
//			System.out.println("its a pldrm num");
//		}else {
//			System.out.println("its not a pldrm num");
//		}
		//---------------------------------------------------//
		
//		Palindrom num
		
//		String name = "madam";
//		int len = name.length();
//		String rev = "";
//		
////		System.out.println(nm);
//		
//		for(int i=len-1; i>=0; i--) {
//			rev= rev+name.charAt(i);
//		}System.out.println(rev);
//		
//		if(name.equals(rev)) {
//			System.out.println("its a plndrm String");
//		}else {
//			System.out.println("its not a pldrm");
//		}
//		
		//-------------------------------------------//
		
//		int num = 8893589;
//		int count = 0;
//		
//		while(num>0) {
//			num= num/10;
//			count++;
//		}System.out.println(count);
		
		
  //-----------------------------------------------------------//
		
		//count EVEN and ODD digits
		
//		int num = 874584;
//		int even=0;
//		int odd=0;
//		
//		while(num>0) {
//			
//			if(num%2==0) {
//				even++;
//			}else {
//				odd++;
//			}
//			num=num/10;
//			
//		}
//		System.out.println(even);
//		System.out.println(odd);
		
		//-----------------------------------------------//
		
		//count sum of digits
		
//		int num=76564;
//		int sum=0;
//		
//		while(num>0) {
//			sum = sum + num%10;
//			num = num/10;
//		}
//		System.out.println(sum);
		
	//----------------------------------------//
		// finding largest number
//		
//		int a = 45;
//		int b = 20;
//		int c = 68;
//		
//		if(a > b && b>c) {
//			System.out.println(a + "is largest");
//		}else if(b>a && b>c){
//			System.out.println(b + "is largest");
//		}else {
//			System.out.println(c+" is largest");
//		}
		//------------------------------------------//
		
		//FIBONACCI SERIES
		
//		int a = 0;
//		int b = 1;
//		int sum = 0;
//		
//		for(int i=2; i<20; i++) {
//			sum=a+b ;
//			System.out.println(sum);
//			a=b;
//			b=sum;
//		}
		//----------------------------------//
		
		//Num is Primr Or Not
		
//		int num = 9;
//		int count = 0;
//		
//		if(num>1) {
//			for(int i=1; i<=num; i++) {
//				if(num%i==0)
//					count++;
//			}
//			if(count==2) {
//				System.out.println("its a prime num");
//			}else {
//				System.out.println("its not a prime");
//			}
//		}
//		else {
//			System.out.println("ist a palondram num");
//			}
	//---------------------------------------------------------//
		
		//Random NUM or String
		
//		Random rand = new Random();
//		int randVal=rand.nextInt(200);
//		System.out.println(randVal);
		
//		String rnd_str = RandomStringUtils.randomAlpha
	//----------------------------------------------------------------//
		
		//Factorial num
		
//		int num = 10;
//		long ftr = 1;
//		
//		for(int i=1; i<=num; i++) {
//			ftr = ftr*i;
//		}
//		System.out.println(ftr);
	//---------------------------------------------------------//
		
		//Sum of Array
		
//		int a[] = {4,5,2,6,9};
//		int sum = 0;
//		
//		for(int i=0; i<=a.length-1; i++) {
//			sum = sum+a[i];
//		}System.out.println(sum);
		
		//-------------------------------------------------------//
		
		//print Even And Odd Num from an Array
//		int a[]= {7,3,6,9,1};
//		int sum = 0;
//		
//		for(int value : a) {
//			if (value%2==0) {
//				System.out.println(value +" is even");
//			}else {
//				System.out.println(value + " is odd");
//			}
//		}
		//---------------------------------------------------------//
		
		//Finding Max Value in an Array
//		int a[]= {7,3,6,9,1};
//		int max = 0;
//		for(int i=0; i<a.length; i++) {
//			if(a[i]>max) {
//				max=a[i];
//			}
//		}System.out.println(max);        ///min is also same place min in place of max
				
			//-------------------------------------------//
		//Finding duplicate elemints
		
//		String name[]= {"thiru", "manu","sonu","thiru"};
//		for(int i=0; i<name.length; i++) {
//			for(int j=i+1; j<name.length; j++) {
//				if(name[i]==name[j]) {
//					System.out.println(name[j]);
//				}
//			}
//		}
	//-----------------------------------------------------------//
		
		//Serching a value in an Array
		
//		int a[] = {5,3,1,9,2,8,6};
//		int b = 3;
//		for(int i=0; i<a.length; i++) {
//			if(a[i]==b) {
//				System.out.println("element is found at "+ i);
//			}
//		}
	//------------------------------------------------------------------//
		//Bubble Sort
//		int a[]= {4,2,7,5,1};
//		
//		for(int i=0 ; i<a.length; i++) {
////		
//			for(int j=i+1; j<a.length; j++) {
////				System.out.println(a[j]);
//				if(a[i]>a[j]) {
//					int temp = a[i];
//					a[i]=a[j];
//					a[j]=temp;
//					
//				}
//			}
//		}
//		System.out.println(Arrays.toString(a));
		
	//----------------------------------------------------------------//
		
		//Revers String 
		
//		String name = "njvbjnvd";
//		String rev = "";
//		
//		for(int i=name.length()-1; i>=0;i--) {
//			rev = rev + name.charAt(i);
//		}System.out.println(rev);
		
//		int a = 98053;
//		int rev =0;
//		
//		while(a!=0) {
//			rev = rev*10 + a%10;
//			a = a/10;
//			System.out.println(rev);
//		}
//		
//		List<Integer> lst = Arrays.asList(10,30,50,20,40,20);
//		
//		Set<Integer> s = new HashSet<>(lst);
//		System.out.println(s);
//		for(Integer c : lst) {
//			System.out.println(c);
//			if(s.add(c)==false)
//				System.out.println("dup"+c);
//				
			
//		}
		//=========================================================--//
		
		//removing spaces from a string
		
//		String name = "hello my nAME IS THIRU";
//		
//		 name = name.replaceAll("\\s","");
//		 System.out.println(name);
		
		//----------------------------------------------------------------//
		
//		String a = "thirumal";
//		String b = "kuma";
//		
//		for(int i=0; i<=a.length(); i++) {
//			for(int j=0; j<=b.length(); j++) {
//				if(a.charAt(i)== b.charAt(j)) {
//					System.out.println(a.charAt(i));
//				}
//			}
//		}
		//------------------------------------------------------------------//
		//factorial of a num
//		int fac=10;
//		if (n==1) {
//			return 1;
//		}else {
//			return(n*fac(n-1));
//		}
		
		String pattern = "MM-dd-yyyy";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		String date = simpleDateFormat.format(new Date());
		System.out.println(date); // 06-23-2020
		
		
		
		}
}
