package Com.prblm_Solving;

import java.util.Scanner;

public class GuessNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int myNum = (int)(Math.random()*100);
		int userNum =0;
		
//		System.out.println("enter ur Num");
		
		do{
			System.out.println("enter ur Num");
			userNum=sc.nextInt();
			if(userNum==myNum) {
				System.out.println("Correct num");
			}
			else if(userNum>myNum) {
				System.out.println("ur num is too large");
			}
			else{
				System.out.println("ur num is too small");
			}
		}
		while(userNum>=0) ;
			System.out.println("my num was "+myNum);
		
		

	}

}
