package Com.prblm_Solving;

import java.util.Iterator;
import java.util.LinkedList;



public class Student {

	public static void main(String[] args) {
		
		LinkedList<String> list= new LinkedList<String>();
		
		list.add("sushma");
		list.add("sunil");
		list.add("anil");
		list.add("amith");
		
		System.out.println(list);
		
		for(String arrString:list) {//for each loop
			System.out.println(arrString);
		System.out.println("----------------------------------------");	
			
		}
		
		Iterator itr = list.iterator();//
		while(itr.hasNext()) {
			System.out.println(itr.next());
//			itr++;
		}
		
		

	}
	

}
