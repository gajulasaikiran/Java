package Com.prblm_Solving;

import java.util.ArrayList;

public class Solve {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> lst = new ArrayList<String>();
		
		lst.add("thiru");
		lst.add("sushma");
		lst.add("raju");
		lst.add("ramesh");
		System.out.println(lst);
		
//		lst.remove(1);
//		System.out.println(lst);
//		
//		lst.remove("raju");
//		System.out.println(lst);
//		
		ArrayList<String> lst1 = new ArrayList<String>();
		
		for(String el:lst) {
			if (el.equals("thiru")) {
				System.out.println(el);
				lst1.add(el);
//				lst.remove(el);
//				System.out.println(el);
			}else {
				lst1.add(el);
			}
		}
		System.out.println(lst1+"added");
		
//	  if(lst.size() != 2) {
//		  System.out.println(lst);
//	  }
//		  else {
//			  System.out.println("false");
//			  }
		  
		
		lst.removeAll(lst);
		System.out.println(lst+"removedAll");
		

	}

}
