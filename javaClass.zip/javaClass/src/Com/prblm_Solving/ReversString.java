package Com.prblm_Solving;

public class ReversString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String name= "thirumal";
//		String rev=" ";
//	    char ch;
//		for(int i=0; i< name.length(); i++) {
//			ch=name.charAt(i);
//			rev=ch+rev;
//		}
//		System.out.println(rev);
//
//	}
   int a=10;
   int b=20;
   
   a=a+b;
   a=a-b;
   b=b-a;
   System.out.println(a);
	}
}
