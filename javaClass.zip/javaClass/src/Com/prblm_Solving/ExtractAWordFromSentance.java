package Com.prblm_Solving;

public class ExtractAWordFromSentance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "today is an holiday";
		System.out.println(s1.subSequence(3,9));
		System.out.println(s1.substring(8,13));
	}

}
